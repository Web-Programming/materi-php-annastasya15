<div>
    <h1>Ini Halaman Beranda</h1>
    <h2>Hallo {{ $name }}</h2>
    <h2>Your Email is {{ $email }}</h2>
    <h2>Address : {{ $alamat }}</h2>
</div>