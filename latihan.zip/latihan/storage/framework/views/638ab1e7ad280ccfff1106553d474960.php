<?php $__env->startSection('title', "Edit Program Studi"); ?>

<?php $__env->startSection('content'); ?>
<!--begin::App Content Header-->
<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6"><h3 class="mb-0">Program Studi</h3></div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(url('/prodi')); ?>">Program Studi</a></li>
          <li class="breadcrumb-item active" aria-current="page">Edit Program Studi</li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!--end::App Content Header-->

<!--begin::App Content-->
<div class="app-content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <!-- Default box -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Edit Program Studi</h3>
            <div class="card-tools">
              <button
                type="button"
                class="btn btn-tool"
                data-lte-toggle="card-collapse"
                title="Collapse"
              >
                <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
              </button>
              <button
                type="button"
                class="btn btn-tool"
                data-lte-toggle="card-remove"
                title="Remove"
              >
                <i class="bi bi-x-lg"></i>
              </button>
            </div>
          </div>

          <div class="card-body">
            <?php if(session('status')): ?>
              <div class="alert alert-success">
                  <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?>

            <!-- Form Edit -->
            <form method="post" action="<?php echo e(url('prodi/' . $prodi->id)); ?>">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?> <!-- dibutuhkan untuk method PUT -->

              <div class="mb-3">
                <label>Nama Prodi</label>
                <input type="text" name="nama" class="form-control"
                       value="<?php echo e(old('nama', $prodi->nama)); ?>">
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="mb-3">
                <label>Kode Prodi</label>
                <input type="text" name="kode_prodi" class="form-control"
                       value="<?php echo e(old('kode_prodi', $prodi->kode_prodi)); ?>">
                <?php $__errorArgs = ['kode_prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <button type="submit" class="btn btn-primary">Update</button>
              <a href="<?php echo e(url('/prodi')); ?>" class="btn btn-secondary">Batal</a>
            </form>
          </div>

          <div class="card-footer">
            Terakhir diubah: <?php echo e($prodi->updated_at->format('d M Y H:i')); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--end::App Content-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\materi-php-annastasya15\latihan\resources\views/prodi/edit.blade.php ENDPATH**/ ?>